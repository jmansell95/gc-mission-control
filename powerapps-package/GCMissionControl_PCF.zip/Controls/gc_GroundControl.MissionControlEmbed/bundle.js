/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./MissionControlEmbed/index.ts"
/*!**************************************!*\
  !*** ./MissionControlEmbed/index.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   MissionControlEmbed: () => (/* binding */ MissionControlEmbed)\n/* harmony export */ });\nvar DEFAULT_APP_URL = \"https://gc-mission-control.base44.app\";\nclass MissionControlEmbed {\n  constructor() {\n    this.loaded = false;\n    // Empty\n  }\n  init(context, _notifyOutputChanged, _state, container) {\n    var _a, _b;\n    this.container = container;\n    this.container.style.width = \"100%\";\n    this.container.style.height = \"100%\";\n    this.container.style.position = \"relative\";\n    this.statusEl = document.createElement(\"div\");\n    this.statusEl.style.cssText = \"position:absolute;inset:0;display:flex;align-items:center;justify-content:center;\" + \"font-family:sans-serif;font-size:13px;color:#666;background:#fafafa;padding:16px;text-align:center;\";\n    this.statusEl.textContent = \"Loading GC Mission Control…\";\n    this.container.appendChild(this.statusEl);\n    var appUrl = ((_b = (_a = context.parameters.appUrl) === null || _a === void 0 ? void 0 : _a.raw) === null || _b === void 0 ? void 0 : _b.trim()) || DEFAULT_APP_URL;\n    this.iframe = document.createElement(\"iframe\");\n    this.iframe.src = appUrl;\n    this.iframe.title = \"GC Mission Control\";\n    this.iframe.style.cssText = \"width:100%;height:100%;border:0;display:block;\";\n    this.iframe.setAttribute(\"sandbox\", \"allow-scripts allow-same-origin allow-forms allow-popups allow-downloads allow-modals\");\n    this.iframe.addEventListener(\"load\", () => {\n      this.loaded = true;\n      this.statusEl.style.display = \"none\";\n    });\n    this.container.appendChild(this.iframe);\n    // If the app never loads (most commonly because it blocks being framed via\n    // X-Frame-Options/CSP frame-ancestors), the iframe fires \"load\" for its own\n    // blocked/error page too in some browsers, so this is a best-effort timeout\n    // hint rather than a definitive check - there is no cross-origin way for the\n    // host page to know for certain why a cross-origin frame is blank.\n    window.setTimeout(() => {\n      if (!this.loaded) {\n        this.statusEl.textContent = \"GC Mission Control did not load. If this app blocks being embedded \" + \"(X-Frame-Options / Content-Security-Policy), embedding it this way isn't possible \" + \"and the app needs to be bundled into the control directly instead.\";\n      }\n    }, 8000);\n  }\n  updateView(context) {\n    var _a, _b;\n    var appUrl = ((_b = (_a = context.parameters.appUrl) === null || _a === void 0 ? void 0 : _a.raw) === null || _b === void 0 ? void 0 : _b.trim()) || DEFAULT_APP_URL;\n    if (this.iframe && this.iframe.src !== appUrl) {\n      this.loaded = false;\n      this.statusEl.style.display = \"flex\";\n      this.statusEl.textContent = \"Loading GC Mission Control…\";\n      this.iframe.src = appUrl;\n    }\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    if (this.iframe) {\n      this.iframe.remove();\n    }\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MissionControlEmbed/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = {};
/******/ 	__webpack_modules__["./MissionControlEmbed/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('GroundControl.MissionControlEmbed', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MissionControlEmbed);
} else {
	var GroundControl = GroundControl || {};
	GroundControl.MissionControlEmbed = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MissionControlEmbed;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}